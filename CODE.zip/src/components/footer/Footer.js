import React from "react";

import "./footer.css";

const Footer = () => (
  <footer>
  </footer>
);

export default Footer;
